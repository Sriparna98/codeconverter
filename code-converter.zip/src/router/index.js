import { createWebHistory, createRouter } from "vue-router";

import home from "../components/Home.vue";
import about from "../components/About.vue";

const routes = [
  {
    path: "/",
    name: "home",
    component: home,
    children: [
      {
        path: "/binaryDecimal",
        name: "binaryDecimal",
        component: () =>
          import("../components/codeConverterComponents/BinarytoDecimal.vue")
      },
      {
        path: "/octalDecimal",
        name: "octalDecimal",
        component: () =>
          import("../components/codeConverterComponents/octalDecimal.vue")
      },
      {
        path: "/hexadecimalDecimal",
        name: "hexadecimalDecimal",
        component: () =>
          import("../components/codeConverterComponents/hexadecimalDecimal.vue")
      }
    ]
  },
  {
    path: "/about",
    name: "about",
    component: about
  }
];
const router = createRouter({
  //mode: history
  history: createWebHistory(),
  routes,
  linkActiveClass: "active-link",
  linkExactActiveClass: "active-link-exact",
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition;
    } else if (to.hash) {
      return { x: 0, y: 0 };
    }
  }
});

export default router;

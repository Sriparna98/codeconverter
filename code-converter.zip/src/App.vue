<template>
  <Header />
  <img alt="Vue logo" src="./assets/logo.png" />
  <hr />
  <br />
  <nav>
    <li><router-link to="/">Home</router-link></li>
    |
    <li><router-link to="/about">About</router-link></li>
    |
    <li><router-link to="/Help">Help</router-link></li>
  </nav>
  <br />
  <hr />
  <br />
  <router-view />
  <!--<HelloWorld msg="Hello Vue 3 in CodeSandbox!" />-->
</template>

<script>
import HeaderVue from "./components/Header.vue";
export default {
  name: "App",
  components: {
    Header: HeaderVue,
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 90px;
}
nav li {
  display: inline;
  list-style-type: none;
  padding: 15px;
}
hr {
  width: 300px;
}
.active-link {
  color: rgb(3, 53, 94);
}
.active-link-exact {
  color: rgb(70, 255, 215);
  font-size: 20px;
  text-decoration: none;
}
</style>

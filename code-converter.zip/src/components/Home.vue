<template>
  <div class="home">
    <h3>HOME</h3>
    <table>
      <tr>
        <td>
          <ul>
            <li>
              <router-link to="/binaryDecimal">Binary-Decimal</router-link>
            </li>
            <li><router-link to="/octalDecimal">Octal-Decimal</router-link></li>
            <li>
              <router-link to="/hexadecimalDecimal"
                >Hexadecimal-Decimal</router-link
              >
            </li>
          </ul>
        </td>
        <td>
          <div>
            <router-view id="children" />
          </div>
        </td>
      </tr>
    </table>
  </div>
</template>
<style scoped>
.home {
  margin: auto;
}
.home table,
td {
  margin: auto;
}
.home table ul li {
  list-style-type: none;
  padding: 15px;
  margin-right: 30px;
  text-align: left;
}
#children {
  align-content: center;
  width: 200px;
  height: 120px;
  border: 1px solid rgb(70, 255, 215);
  border-radius: 10px;
  padding: 30px;
  background-image: linear-gradient(
    to bottom right,
    rgb(2, 57, 102),
    rgb(70, 255, 215)
  );
}
</style>
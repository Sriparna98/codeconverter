<template>
  <div>
    <input
      type="number"
      v-model="decimalVal"
      placeholder="Enter decimal number"
    />
    <br /><br />
    <input type="number" v-model="octalVal" placeholder="Enter octal number" />
    <br /><br />
    <button type="submit" v-on:click="clear()">Clear</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      decimalVal: "",
      octalVal: "",
    };
  },
  watch: {
    decimalVal: function (val) {
      this.decimalVal = val;
      this.octalVal = this.decimalVal.toString(8);
    },
    octalVal: function (val) {
      this.octalVal = val;
      this.decimalVal = parseInt(this.octalVal, 8);
    },
  },
  methods: {
    clear: function () {
      this.decimalVal = "";
      this.octalVal = "";
    },
  },
};
</script>
<style scoped>
input {
  height: 25px;
  border-radius: 5px;
  border: 2px solid rgb(70, 255, 215);
}
button {
  width: 70px;
  height: 30px;
  border-radius: 5px;
  font-weight: bold;
  color: white;
  background-color: rgb(3, 53, 94);
  border: 2px solid rgb(70, 255, 215);
}
button:hover {
  background-color: rgb(70, 255, 215);
  color: rgb(3, 53, 94);
  box-shadow: 1px 5px 20px 2px rgb(3, 53, 94);
}
input:hover {
  box-shadow: 0 0 5px 1px rgb(3, 53, 94);
}
</style>
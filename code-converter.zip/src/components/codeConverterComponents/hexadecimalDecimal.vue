<template>
  <div>
    <input
      type="number"
      v-model="decimalVal"
      placeholder="Enter decimal number"
    />
    <br /><br />
    <input
      type="text"
      v-model="hexdecimalVal"
      placeholder="Enter hexadecimal number"
    />
    <br /><br />
    <button type="submit" v-on:click="clear()">Clear</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      decimalVal: "",
      hexdecimalVal: "",
    };
  },
  watch: {
    decimalVal: function (val) {
      this.decimalVal = val;
      this.hexdecimalVal = this.decimalVal.toString(16);
    },
    hexdecimalVal: function (val) {
      this.hexdecimalVal = val;
      this.decimalVal = parseInt(this.hexdecimalVal, 16);
    },
  },
  methods: {
    clear: function () {
      this.decimalVal = "";
      this.hexdecimalVal = "";
    },
  },
};
</script>
<style scoped>
input {
  height: 25px;
  border-radius: 5px;
  border: 2px solid rgb(70, 255, 215);
}
button {
  width: 70px;
  height: 30px;
  border-radius: 5px;
  font-weight: bold;
  color: white;
  background-color: rgb(3, 53, 94);
  border: 2px solid rgb(70, 255, 215);
}
button:hover {
  background-color: rgb(70, 255, 215);
  color: rgb(3, 53, 94);
  box-shadow: 1px 5px 20px 2px rgb(3, 53, 94);
}
input:hover {
  box-shadow: 0 0 5px 1px rgb(3, 53, 94);
}
</style>
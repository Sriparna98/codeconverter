<template>
  <div class="header">
    <h1>Code Converter</h1>
  </div>
</template>
<style scoped>
.header {
  width: 100%;
  height: 70px;
  color: white;
  background-color: rgb(3, 53, 94);
  box-shadow: 1px 1px 10px 2px rgb(9, 180, 143);
  font-size: 20px;
  position: fixed;
  top: 0;
  left: 0;
}
.header h1 {
  text-align: left;
  padding-left: 10px;
}
</style>